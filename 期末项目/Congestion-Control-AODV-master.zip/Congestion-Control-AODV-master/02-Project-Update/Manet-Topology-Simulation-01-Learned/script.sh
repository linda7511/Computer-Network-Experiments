./waf --run "scratch/manet-routing-compare --CSVfileName=kkp_OLSR --protocol=1"
./waf --run "scratch/manet-routing-compare --CSVfileName=kkp_AODV --protocol=2"
./waf --run "scratch/manet-routing-compare --CSVfileName=kkp_DSDV --protocol=3"
./waf --run "scratch/manet-routing-compare --CSVfileName=kkp_DSR --protocol=4"
